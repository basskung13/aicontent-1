import './assets/index.js-DAPgYiEi.js';
