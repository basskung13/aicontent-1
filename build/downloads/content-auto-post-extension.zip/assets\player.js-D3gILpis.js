(function(){console.log("▶️ Auto Post Agent: Player Loaded");if(window.playerInjected)console.log("⚠️ Player already injected.");else{window.playerInjected=!0;const r=e=>new Promise(a=>setTimeout(a,e)),c=async(e,a=15e3)=>{const n=Date.now();let t=0;for(;Date.now()-n<a;){t++;let o=null;try{if(e.includes("::text=")){const i=e.split("::text="),s=i[0]||"*";let l=i[1];(l.startsWith('"')&&l.endsWith('"')||l.startsWith("'")&&l.endsWith("'"))&&(l=l.slice(1,-1)),l=l.replace(/\\n/g,`
`);const d=`//${s}[contains(., "${l.split(`
`)[0]}") or contains(., '${l}')]`;if(o=document.evaluate(d,document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue,!o){const b=document.getElementsByTagName(s);for(let p of b)if(p.innerText.includes(l)){o=p;break}}}else if(e.includes("text=")){const s=`//*[contains(text(), '${e.split("text=")[1].replace(/["']/g,"")}')]`;o=document.evaluate(s,document,null,XPathResult.FIRST_ORDERED_NODE_TYPE,null).singleNodeValue}else o=document.querySelector(e)}catch{}if(o)return console.log(`✅ Found: ${e}`,o),o.style.outline="3px solid #facc15",o.style.transition="all 0.2s",setTimeout(()=>o.style.outline="",1e3),o;await r(500)}throw console.warn(`⏱️ Element not found after ${t} attempts (${a/1e3}s): ${e}`),new Error(`Element not found after ${a/1e3}s: ${e}`)},f=async e=>(console.log("📤 Attempting File Upload..."),new Promise(a=>{chrome.runtime.sendMessage({action:"FETCH_ASSET"},async n=>{if(!n||n.error){console.error("❌ Asset Fetch Failed:",n?.error),alert("⚠️ Auto Post Agent: Could not fetch asset for upload."),a(!1);return}try{const o=await(await fetch(n.dataUri)).blob(),i=new File([o],n.filename,{type:n.mime}),s=new DataTransfer;s.items.add(i),e.files=s.files,e.dispatchEvent(new Event("change",{bubbles:!0})),e.dispatchEvent(new Event("input",{bubbles:!0})),console.log(`✅ Uploaded: ${n.filename}`),a(!0)}catch(t){console.error("❌ Upload Injection Failed:",t),a(!1)}})})),m=async(e,a=3e5)=>{console.log(`⏳ Waiting for element to appear: ${e} (timeout: ${a/1e3}s)`);const n=Date.now();for(;Date.now()-n<a;){if(document.querySelector(e))return console.log(`✅ Element appeared: ${e}`),!0;await r(1e3)}return console.warn(`⏱️ Timeout waiting for element: ${e}`),!1},g=async(e,a=3e5)=>{console.log(`⏳ Waiting for element to disappear: ${e} (timeout: ${a/1e3}s)`);const n=Date.now();let t=!1;for(;Date.now()-n<3e4;){if(document.querySelector(e)){t=!0,console.log("📍 Element found, now waiting for it to disappear...");break}await r(500)}if(!t)return console.log("⚠️ Element never appeared, continuing..."),!0;for(;Date.now()-n<a;){if(!document.querySelector(e))return console.log(`✅ Element disappeared: ${e}`),!0;await r(1e3)}return console.warn(`⏱️ Timeout waiting for element to disappear: ${e}`),!1},y=e=>{const a=document.querySelectorAll(e).length;return console.log(`📊 Count of "${e}": ${a}`),a},u=async(e,a={})=>{console.log(`🚀 Executing: ${e.action} on ${e.selector||"N/A"}`);try{if(await r(500),e.action==="wait_for_element"){const t=e.timeout||3e5;return await m(e.selector,t)}if(e.action==="wait_for_disappear"){const t=e.timeout||3e5;return await g(e.selector,t)}if(e.action==="count_elements"){const t=y(e.selector);return window.__sceneCount=t,!0}if(e.action==="wait"){const t=e.duration||e.value||1e3;return console.log(`⏳ Waiting ${t}ms...`),await r(t),!0}const n=await c(e.selector);if(e.action==="click")n.click();else if(e.action==="type"||e.action==="input")if(n.type==="file")await f(n);else{let t=e.value||"Test Input";typeof t=="string"&&t.includes("{{")&&(console.log(`🧠 Parsing Variables in: "${t}"`),Object.keys(a).forEach(o=>{const i=new RegExp(`{{${o}}}`,"g");let s=a[o];Array.isArray(s)?s=s.join(", "):typeof s=="object"&&s!==null?s=JSON.stringify(s):s==null&&(s=""),t=t.replace(i,String(s))}),console.log(`🧠 Result: "${t.substring(0,100)}..."`)),n.value=t,n.dispatchEvent(new Event("input",{bubbles:!0})),n.dispatchEvent(new Event("change",{bubbles:!0}))}return!0}catch(n){return console.error("❌ Step Failed:",n),!1}},w=e=>{const a=document.getElementById("agent-step-overlay");a&&a.remove();const n=document.createElement("div");if(n.id="agent-step-overlay",n.style.cssText=`
            position: fixed;
            top: 10px;
            left: 50%;
            transform: translateX(-50%);
            background: linear-gradient(135deg, #fbbf24 0%, #f59e0b 100%);
            color: #000;
            padding: 10px 20px;
            border-radius: 8px;
            font-family: 'Segoe UI', sans-serif;
            font-size: 14px;
            font-weight: bold;
            z-index: 999999;
            box-shadow: 0 4px 20px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease-out;
        `,!document.getElementById("agent-overlay-style")){const o=document.createElement("style");o.id="agent-overlay-style",o.textContent=`
                @keyframes slideDown {
                    from { transform: translateX(-50%) translateY(-100%); opacity: 0; }
                    to { transform: translateX(-50%) translateY(0); opacity: 1; }
                }
                @keyframes pulse {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.5; }
                }
            `,document.head.appendChild(o)}const t=e.blockName?`[${e.blockIndex+1}/${e.totalBlocks}] ${e.blockName}`:"";n.innerHTML=`
            <span style="animation: pulse 1s infinite;">🧪</span>
            <span>ทดสอบ: ${t}</span>
            <span style="background: rgba(0,0,0,0.2); padding: 2px 8px; border-radius: 4px;">
                Step ${e.stepIndex+1}/${e.totalSteps}
            </span>
            <span style="font-weight: normal; font-size: 12px;">${e.action||""}</span>
        `,document.body.appendChild(n),setTimeout(()=>{n.parentNode&&(n.style.opacity="0",n.style.transition="opacity 0.3s",setTimeout(()=>n.remove(),300))},2e3)},E=e=>{if(!e)return;const a=e.style.outline,n=e.style.transition;e.style.outline="4px solid #fbbf24",e.style.transition="outline 0.2s ease-out",e.scrollIntoView({behavior:"smooth",block:"center"}),setTimeout(()=>{e.style.outline=a,e.style.transition=n},1500)};chrome.runtime.onMessage.addListener((e,a,n)=>{if(e.action==="EXECUTE_STEP_WITH_HIGHLIGHT"){const t=e.step;return console.log(`🧪 Test Step ${e.stepIndex+1}/${e.totalSteps}:`,t),w({stepIndex:e.stepIndex,totalSteps:e.totalSteps,blockName:e.blockName,blockIndex:e.blockIndex||0,totalBlocks:e.totalBlocks||1,action:`${t.action} → ${t.selector?.substring(0,30)||"N/A"}...`}),(async()=>{try{if(t.selector)try{const o=await c(t.selector,5e3);E(o)}catch{console.warn("Element not found for highlight:",t.selector)}await u(t,{}),n({success:!0})}catch(o){console.error("Step execution error:",o),n({success:!1,error:o.message})}})(),!0}if(e.action==="EXECUTE_RECIPE"){const t=e.recipe||{},o=t.steps||[],i=t.variables||{};console.log("📜 Starting Recipe...",{stepsCount:o.length,variables:i}),(async()=>{let s=!0;for(const l of o){if(!await u(l,i)){s=!1;break}await r(1e3)}s?(console.log("✅ Recipe Complete!"),chrome.runtime.sendMessage({action:"RECIPE_STATUS_UPDATE",status:"COMPLETED",recipeId:t.id})):(console.warn("⚠️ Recipe Stopped due to error."),chrome.runtime.sendMessage({action:"RECIPE_STATUS_UPDATE",status:"FAILED",recipeId:t.id,error:"Step Execution Failed"}))})(),n({status:"STARTED"})}})}
})()
